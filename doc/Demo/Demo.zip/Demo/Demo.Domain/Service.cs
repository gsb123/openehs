﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Demo.Domain
{
    public class Service
    {
        private int id { get; set; }
        public string name { get; set; }
        public decimal servicecost { get; set; }
    }
}
