﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MySql.Data.MySqlClient;
using Demo.Domain;

namespace Demo.Data
{
    public class DataTier
    {
        private const string ConnectionString = "server=localhost;" +
                                           "user id=OpenEHS_admin;" +
                                           "password=password;" +
                                           "database=OpenEHS_database;" +
                                           "pooling=false;";

        public void insetService(Service service)
        {
            string procName = "sp_insertService";
            string connectionString = "Server=localhost;Database=OpenEHS_database;Uid=OpenEHS_admin;Pwd=password;";

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();

                using (MySqlCommand cmd = new MySqlCommand(procName, conn))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.Add(new MySqlParameter("UserName", service.name));
                    cmd.Parameters.Add(new MySqlParameter("Password", service.servicecost));

                    cmd.ExecuteNonQuery();

                }
            }
        }
    }
}
